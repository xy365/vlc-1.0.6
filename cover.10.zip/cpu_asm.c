#include <windows.h>
#include <stdio.h>

#include "config.h"
#include "cpu_asm.h"

void cover_cpuid(unsigned int reg, unsigned int *i_eax, unsigned int *i_ebx, unsigned int *i_ecx, unsigned int *i_edx)
{
    asm volatile ( "push %%ebx\n\t"
                   "cpuid\n\t"
                   "movl %%ebx,%1\n\t"
                   "pop %%ebx\n\t"
                 : "=a" ( *i_eax ),
                   "=r" ( *i_ebx ),
                   "=c" ( *i_ecx ),
                   "=d" ( *i_edx )
                 : "a"  ( reg )
                 : "cc" );
}

void cover_CPUCapabilities1(unsigned int *i_eax, unsigned int *i_ebx)
{
    /* check if cpuid instruction is supported */
    asm volatile ( "push %%ebx\n\t"
                   "pushf\n\t"
                   "pop %%eax\n\t"
                   "movl %%eax, %%ebx\n\t"
                   "xorl $0x200000, %%eax\n\t"
                   "push %%eax\n\t"
                   "popf\n\t"
                   "pushf\n\t"
                   "pop %%eax\n\t"
                   "movl %%ebx,%1\n\t"
                   "pop %%ebx\n\t"
                 : "=a" ( *i_eax ),
                   "=r" ( *i_ebx )
                 :
                 : "cc" );
}

