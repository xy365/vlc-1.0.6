#include <windows.h>
#include <stdio.h>
#include <stdint.h>

#include "config.h"

#include "memcpy_asm.h"

#undef HAVE_MMX
#undef HAVE_MMX2
#undef HAVE_SSE
#undef HAVE_SSE2
#undef HAVE_3DNOW
#undef HAVE_ALTIVEC

#define PRIORITY 100
#define HAVE_3DNOW

#include "fastmemcpy.h"

void *cover_fast_memcpy_3dn(void * to, const void * from, size_t len)
{
	return fast_memcpy(to, from, len);
}

