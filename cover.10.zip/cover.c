#include <windows.h>
#include <stdio.h>
#include <libintl.h>
#include <iconv.h>
#include <dirent.h>
#include <inttypes.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <time.h>
#include <sys/time.h>
#include <math.h>
#include <search.h>

#define INT64_C(val) val##LL

#ifndef _SIZE_T_DEFINED
typedef unsigned int size_t;
#define _SIZE_T_DEFINED
#endif

typedef int64_t mtime_t;
#include "cover.h"
#include "cover_search.h"

#define _T(x) x

char *cover_bindtextdomain (const char *__domainname, const char *__dirname)
{
	return bindtextdomain(__domainname, __dirname);
}

char *cover_bind_textdomain_codeset (const char *__domainname, const char *__codeset)
{
  return bind_textdomain_codeset(__domainname, __codeset);
}

char *cover_dgettext (const char *__domainname, const char *__msgid)
{
  return dgettext(__domainname, __msgid);
}

iconv_t cover_iconv_open (const char* tocode, const char* fromcode)
{
	return iconv_open(tocode, fromcode);
}

size_t cover_iconv (iconv_t cd, const char* * inbuf, size_t *inbytesleft, char* * outbuf, size_t *outbytesleft)
{
	return iconv(cd, (char* *)inbuf, inbytesleft, outbuf, outbytesleft);
}

int cover_iconv_close (iconv_t cd)
{
	return iconv_close(cd);
}

_WDIR* cover_wopendir (const wchar_t* dir)
{
	return _wopendir(dir);
}

struct _wdirent* cover_wreaddir (_WDIR* dir)
{
	return _wreaddir(dir);
}

int cover_wclosedir (_WDIR* dir)
{
	return _wclosedir(dir);
}

void cover_wrewinddir (_WDIR* dir)
{
	_wrewinddir(dir);
}

mtime_t cover_mdate( void )
{
    mtime_t res;

    /* We don't need the real date, just the value of a high precision timer */
    static mtime_t freq = INT64_C(-1);

    if( freq == INT64_C(-1) )
    {
        /* Extract from the Tcl source code:
         * (http://www.cs.man.ac.uk/fellowsd-bin/TIP/7.html)
         *
         * Some hardware abstraction layers use the CPU clock
         * in place of the real-time clock as a performance counter
         * reference.  This results in:
         *    - inconsistent results among the processors on
         *      multi-processor systems.
         *    - unpredictable changes in performance counter frequency
         *      on "gearshift" processors such as Transmeta and
         *      SpeedStep.
         * There seems to be no way to test whether the performance
         * counter is reliable, but a useful heuristic is that
         * if its frequency is 1.193182 MHz or 3.579545 MHz, it's
         * derived from a colorburst crystal and is therefore
         * the RTC rather than the TSC.  If it's anything else, we
         * presume that the performance counter is unreliable.
         */
        LARGE_INTEGER buf;

        freq = ( QueryPerformanceFrequency( &buf ) &&
                 (buf.QuadPart == INT64_C(1193182) || buf.QuadPart == INT64_C(3579545) ) )
               ? buf.QuadPart : 0;

        /* on windows 2000, XP and Vista detect if there are two
           cores there - that makes QueryPerformanceFrequency in
           any case not trustable?
           (may also be true, for single cores with adaptive
            CPU frequency and active power management?)
        */
        HINSTANCE h_Kernel32 = LoadLibrary(_T("kernel32.dll"));
        if(h_Kernel32)
        {
            void WINAPI (*pf_GetSystemInfo)(LPSYSTEM_INFO);
            pf_GetSystemInfo = (void WINAPI (*)(LPSYSTEM_INFO))
                                GetProcAddress(h_Kernel32, _T("GetSystemInfo"));
            if(pf_GetSystemInfo)
            {
               SYSTEM_INFO system_info;
               pf_GetSystemInfo(&system_info);
               if(system_info.dwNumberOfProcessors > 1)
                  freq = 0;
            }
            FreeLibrary(h_Kernel32);
        }
    }

    if( freq != 0 )
    {
        LARGE_INTEGER counter;
        QueryPerformanceCounter (&counter);

        /* Convert to from (1/freq) to microsecond resolution */
        /* We need to split the division to avoid 63-bits overflow */
        lldiv_t d = lldiv (counter.QuadPart, freq);

        res = (d.quot * 1000000) + ((d.rem * 1000000) / freq);
    }
    else
    {
        /* Fallback on timeGetTime() which has a milisecond resolution
         * (actually, best case is about 5 ms resolution)
         * timeGetTime() only returns a DWORD thus will wrap after
         * about 49.7 days so we try to detect the wrapping. */

        static CRITICAL_SECTION date_lock;
        static mtime_t i_previous_time = INT64_C(-1);
        static int i_wrap_counts = -1;

        if( i_wrap_counts == -1 )
        {
            /* Initialization */
            i_previous_time = INT64_C(1000) * timeGetTime();
            InitializeCriticalSection( &date_lock );
            i_wrap_counts = 0;
        }

        EnterCriticalSection( &date_lock );
        res = INT64_C(1000) *
            (i_wrap_counts * INT64_C(0x100000000) + timeGetTime());
        if( i_previous_time > res )
        {
            /* Counter wrapped */
            i_wrap_counts++;
            res += INT64_C(0x100000000) * 1000;
        }
        i_previous_time = res;
        LeaveCriticalSection( &date_lock );
    }

    return res;
}

void * cover_tsearch (const void *key, void **vrootp, int (*compar) (const void *, const void *))
{
	return tsearch(key, vrootp, compar);
}

void * cover_tfind (const void *key, void *const *vrootp, int (*compar) (const void *, const void *))
{
	return tfind(key, vrootp, compar);
}

void *cover_tdelete (const void *key, void **vrootp, int (*compar) (const void *, const void *))
{
	return tdelete(key, vrootp, compar);
}

void cover_twalk (const void *vroot, void (*action) (const void *, VISIT, int))
{
	twalk(vroot, action);
}

int cover__fpclassifyf(float x)
{
	return __fpclassifyf(x);
}

int cover__fpclassify(double x)
{
	return __fpclassify(x);
}

int cover__fpclassifyl(long double x)
{
	return __fpclassifyl(x);
}

void cover_CPUCapabilities_sub1()
{
	__asm__ __volatile__ ( "xorps %%xmm0,%%xmm0\n" : : );
}

void cover_CPUCapabilities_sub2()
{
	__asm__ __volatile__ ( "movupd %%xmm0, %%xmm0\n" : : );
}

void cover_CPUCapabilities_sub3()
{
	__asm__ __volatile__ ( "pfadd %%mm0,%%mm0\n" "femms\n" : : );
}

