#ifndef __CPU_ASM_H__
#define __CPU_ASM_H__

#include <cover_base.h>

EXTERN_SYMBOL DLL_SYMBOL void CDECL_SYMBOL cover_MergeMMXEXT( void *_p_dest, const void *_p_s1, const void *_p_s2,
                         size_t i_bytes );
EXTERN_SYMBOL DLL_SYMBOL void CDECL_SYMBOL cover_Merge3DNow( void *_p_dest, const void *_p_s1, const void *_p_s2,
                        size_t i_bytes );
EXTERN_SYMBOL DLL_SYMBOL void CDECL_SYMBOL cover_MergeSSE2( void *_p_dest, const void *_p_s1, const void *_p_s2,
                       size_t i_bytes );

#endif