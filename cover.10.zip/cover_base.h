#ifndef __COVER_BASE_H__
#define __COVER_BASE_H__

#define DLL_SYMBOL              __declspec(dllexport)
#define CDECL_SYMBOL            __cdecl
#define EXTERN_SYMBOL           extern "C"

#endif

